-> Final_Price_Prediction.ipynb is the notebook which contains my source code.
-> BP.csv is the output file of blended stacked regressors and is my final csv for price prediction.
-> GBPredict.csv is the price predicted using Gradient Boosting regression model.
-> RFPredict.csv is the price predicted using Random Forest regression model.
-> XGPredict.csv is the price predicted using XG Boost regression model.

Note: BP.csv to be used for final prediction output.